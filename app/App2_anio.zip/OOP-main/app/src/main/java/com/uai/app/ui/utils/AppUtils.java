package com.uai.app.ui.utils;

public class AppUtils {

    public static boolean isNull(Object obj){
        return  obj == null;
    }
    public static boolean isNotNull(Object obj){
        return  obj != null;
    }
}
