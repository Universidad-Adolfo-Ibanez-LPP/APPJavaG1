package com.uai.app.ui;

import com.uai.app.dominio.Libro;
import com.uai.app.logic.DataManager;
import com.uai.app.ui.utils.UAIJFrame;
import com.uai.app.ui.utils.UIBuilder;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashSet;

public class BuscarDatosUI extends UAIJFrame {
    private JPanel mainPanel;
    private JTextArea textArea1;
    private JLabel titulo;
    private JTextField lib;
    private JPanel mainTableConatiner;
    private JButton enviar;
    private JComboBox comboBox1;
    private JButton limpiar;


    public BuscarDatosUI(String title) {
        super(title);
        this.setMainPanel(mainPanel);
        enviar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String libr = lib.getText();
                int option = comboBox1.getSelectedIndex();
                String[] titles = {"titulo", "autor", "estante_numero", "estante_seccion", "piso", "edificio", "sede"};
                //obtengo los libros en una matriz

                HashSet<Libro> data = DataManager.getInstance().getData();
                String[][] dataTabla = new String[data.size()][7];
                int cont = 0;
                for(Libro p : data) {
                    if(option==1){
                        if(p.getTitulo().equals(libr)){
                            dataTabla[cont] = p.getDataToCsv();
                            cont++;
                        }
                    }
                    if(option==2){
                        if(p.getAutor().equals(libr)){
                            dataTabla[cont] = p.getDataToCsv();
                            cont++;
                        }
                    }
                    if(option==3){
                        if(String.valueOf(p.getEstante_numero()).equals(libr)){
                            dataTabla[cont] = p.getDataToCsv();
                            cont++;
                        }
                    }
                    if(option==4){
                        if(p.getEstante_seccion().equals(libr)){
                            dataTabla[cont] = p.getDataToCsv();
                            cont++;
                        }
                    }
                    if(option==5){
                        if(String.valueOf(p.getPiso()).equals(libr)){
                            dataTabla[cont] = p.getDataToCsv();
                            cont++;
                        }
                    }
                    if(option==6){
                        if(p.getEdificio().equals(libr)){
                            dataTabla[cont] = p.getDataToCsv();
                            cont++;
                        }
                    }
                    if(option==7){
                        if(String.valueOf(p.getSede()).equals(libr)){
                            dataTabla[cont] = p.getDataToCsv();
                            cont++;
                        }
                    }
                }

                TableModel tableModel = new DefaultTableModel(dataTabla, titles);
                JTable table = new JTable(tableModel);
                mainTableConatiner.setLayout(new BorderLayout());
                mainTableConatiner.add(new JScrollPane(table), BorderLayout.CENTER);

                mainTableConatiner.add(table.getTableHeader(), BorderLayout.NORTH);

                mainTableConatiner.setVisible(true);
                mainTableConatiner.setSize(400,400);
                limpiar.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        for (int i = 0; i < table.getRowCount(); i++){
                            for(int j = 0; j < table.getColumnCount(); j++) {
                                table.setValueAt("", i, j);
                            }
                        }
                    }
                });

            }

        });


}
}
