package com.uai.app.ui;
import com.uai.app.logic.*;

import com.uai.app.dominio.Libro;
import com.uai.app.logic.builders.LibroBuilder;
import com.uai.app.ui.utils.UAIJFrame;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashSet;

public class AgregarDatosUI extends UAIJFrame {
    private JLabel encabezado;
    private JTextField titulo;
    private JTextField autor;
    private JTextField estante_numero;
    private JTextField estante_seccion;
    private JTextField piso;
    private JTextField edificio;
    private JTextField sede;
    private JButton agregarButton;
    private JPanel mainPanel;
    private JTextField anio;
    private JLabel anioo;

    public AgregarDatosUI(String title) {
        super(title);
        this.setMainPanel(mainPanel);
        agregarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String tit=titulo.getText();
                String aut=autor.getText();
                String est=estante_seccion.getText();
                String edi=edificio.getText();
                String sed=sede.getText();
                int enu=Integer.parseInt(estante_numero.getText());
                int an=Integer.parseInt(anio.getText());
                int pis=Integer.parseInt(piso.getText());
                HashSet<Libro> data = DataManager.getInstance().getData();
                LibroBuilder bo = new LibroBuilder();
                JFrame jFrame= new JFrame();
                JOptionPane.showMessageDialog(jFrame,"¡Libro Agregado!");
                data.add(bo.build(aut,enu,est,tit,pis,edi,sed,an));
                dispose();




            }
        });
    }
}
