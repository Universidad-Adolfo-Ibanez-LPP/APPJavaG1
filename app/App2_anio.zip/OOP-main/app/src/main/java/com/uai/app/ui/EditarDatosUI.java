package com.uai.app.ui;

import javax.swing.*;

import com.uai.app.dominio.Libro;
import com.uai.app.logic.DataManager;
import com.uai.app.logic.builders.LibroBuilder;
import com.uai.app.ui.utils.UAIJFrame;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashSet;

public class EditarDatosUI extends UAIJFrame{
    private JLabel Encabezado;
    private JPanel panelito;
    private JComboBox comboBox1;
    private JTextField Cambio;
    private JButton Botoncito;
    private JTextField Titulo;
    private JLabel Enunciado;
    private JLabel Enunciado2;

    public EditarDatosUI(String title) {
        super(title);
        this.setMainPanel(panelito);


        Botoncito.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String cambio = Cambio.getText();
                String libr = Titulo.getText();
                int option = comboBox1.getSelectedIndex();

                HashSet<Libro> data = DataManager.getInstance().getData();
                for(Libro p : data) {
                    if (p.getTitulo().equals(libr)){
                        if (option==1){
                            p.setTitulo(cambio);
                        }

                        if (option==2){
                            p.setAutor(cambio);
                        }

                        if (option==3){
                            p.setAnio(Integer.parseInt(cambio));
                        }

                        if (option==4){
                            p.setEstante_numero(Integer.parseInt(cambio));
                        }

                        if (option==5){
                            p.setEstante_seccion(cambio);
                        }

                        if (option==6){
                            p.setPiso(Integer.parseInt(cambio));
                        }

                        if (option==7){
                            p.setEdificio(cambio);
                        }

                        if (option==8){
                            p.setSede(cambio);
                        }
                    }
                }

                JFrame jFrame= new JFrame();
                JOptionPane.showMessageDialog(jFrame,"¡Libro Editado!");
                dispose();
            }
        });
    }
}
