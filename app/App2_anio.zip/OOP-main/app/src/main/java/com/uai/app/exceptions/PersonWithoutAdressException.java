package com.uai.app.exceptions;

public class PersonWithoutAdressException extends Exception{
}
